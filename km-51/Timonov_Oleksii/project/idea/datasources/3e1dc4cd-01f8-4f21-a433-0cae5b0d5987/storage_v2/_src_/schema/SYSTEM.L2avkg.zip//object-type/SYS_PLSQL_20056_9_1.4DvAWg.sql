create type          SYS_PLSQL_20056_9_1 as object (ADDRESS VARCHAR2(30 CHAR),
DATETIME DATE);
/

