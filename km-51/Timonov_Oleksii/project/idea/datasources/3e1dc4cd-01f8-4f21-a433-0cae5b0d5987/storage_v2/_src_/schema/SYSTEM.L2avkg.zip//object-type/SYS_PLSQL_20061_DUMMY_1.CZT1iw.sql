create type          SYS_PLSQL_20061_DUMMY_1 as table of number;
/

