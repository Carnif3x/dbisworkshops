create PACKAGE PERSON_PACKAGE AS
  TYPE T_USER IS RECORD (
    EMAIL VARCHAR2(30 CHAR),
    FIRST_NAME VARCHAR2(30 CHAR),
    last_name VARCHAR2(30 CHAR),
    password VARCHAR2(30 CHAR)
    );

  TYPE T_USER_TABLE IS TABLE OF T_USER;

  FUNCTION LOG_IN(your_email IN PERSON.EMAIL%TYPE, PASS IN PERSON.PASSWORD%TYPE)
    RETURN NUMBER;

  FUNCTION GET_PERSON(PERSON_EMAIL IN PERSON.EMAIL%type)
    RETURN T_USER_TABLE PIPELINED;

  function REGISTRATION(new_email IN PERSON.EMAIL%TYPE,
                        new_first_name IN PERSON.FIRST_NAME%TYPE,
                        NEW_last_name IN PERSON.LAST_NAME%TYPE,
                        NEW_pass IN PERSON.PASSWORD%TYPE)
    return VARCHAR2;

  function update_user(user_email IN PERSON.EMAIL%TYPE,
                       new_first_name IN PERSON.FIRST_NAME%TYPE,
                       NEW_last_name IN PERSON.LAST_NAME%TYPE,
                       NEW_pass IN PERSON.PASSWORD%TYPE)
    return varchar2;
END;
/

