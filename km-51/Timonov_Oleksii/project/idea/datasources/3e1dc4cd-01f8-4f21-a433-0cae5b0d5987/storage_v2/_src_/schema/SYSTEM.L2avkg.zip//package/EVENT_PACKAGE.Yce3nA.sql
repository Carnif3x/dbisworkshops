create PACKAGE EVENT_PACKAGE AS
  TYPE T_EVENT IS RECORD (
    EV_TITLE VARCHAR2(30 CHAR),
    EV_TOPIC VARCHAR2(30 CHAR),
    EV_DESC VARCHAR2(1000 CHAR),
    EV_PRICE BINARY_DOUBLE,
    EV_ORG varchar2(30 char),
    ID_EVENT NUMBER,
    deleted varchar2(30 char)
    );

  TYPE T_EVENT_TABLE IS TABLE OF T_EVENT;

  FUNCTION GET_EVENT(EV_ID IN EVENT.ID%TYPE)
    RETURN T_EVENT_TABLE PIPELINED;
  FUNCTION GET_EVENTS_BY_TOPIC(EV_TOPIC IN EVENT.TOPIC%TYPE)
    RETURN T_EVENT_TABLE PIPELINED;
  FUNCTION GET_EVENTS
    RETURN T_EVENT_TABLE PIPELINED;
  function ADD_EVENT(ev_title IN EVENT.TITLE%TYPE,
                     ev_topic IN EVENT.TOPIC%TYPE,
                     ev_desc IN EVENT."desc"%TYPE,
                     ev_price IN EVENT.PRICE%type,
                     ev_org IN EVENT.ORGANIZER%type)
    return VARCHAR2;
  function update_event(ev_title in EVENT.TITLE%type,
                        ev_topic in EVENT.TOPIC%type,
                        ev_desc in EVENT."desc"%type,
                        ev_price in EVENT.PRICE%type,
                        ev_id in EVENT.ID%type,
                        ev_email in EVENT.ORGANIZER%TYPE)
    return varchar2;

  FUNCTION GET_ORGANIZER_EVENT(EMAIL IN EVENT.ORGANIZER%TYPE)
    RETURN T_EVENT_TABLE PIPELINED ;

  function delete_event(ev_id in EVENT.ID%type, ev_email in EVENT.ORGANIZER%TYPE)
    return VARCHAR2;
END;
/

