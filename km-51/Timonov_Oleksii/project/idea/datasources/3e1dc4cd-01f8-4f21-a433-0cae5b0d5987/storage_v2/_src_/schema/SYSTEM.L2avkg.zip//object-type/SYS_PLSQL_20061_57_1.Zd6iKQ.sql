create type          SYS_PLSQL_20061_57_1 as table of "SYSTEM"."SYS_PLSQL_20061_9_1";
/

